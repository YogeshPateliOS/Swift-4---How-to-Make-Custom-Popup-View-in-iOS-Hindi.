//
//  ViewController.swift
//  PopControllerDemo
//
//  Created by Yogesh Patel on 15/09/18.
//  Copyright © 2018 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var btnClick: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func btnSelectClick(_ sender: UIButton) {
        let popController = PopoverController(items: setupPopItem(), fromView: btnClick, direction: .up, reverseHorizontalCoordinates: true, style: PopoverStyle.normal, initialIndex: 1) {
            print("Yeah Done !!")
        }
        popover(popController)
    }


    private func setupPopItem() -> [PopoverItem]{
        let google = PopoverItem(title: "Google", titleColor: .clear, image: #imageLiteral(resourceName: "a1")) {
            debugPrint($0.title) // code here for click event
        }
        let fb = PopoverItem(title: "FB", titleColor: .clear, image: #imageLiteral(resourceName: "a3")){
            debugPrint($0.title) // code here for click event
        }
        let twitter = PopoverItem(title: "Twitter", titleColor: .clear, image: #imageLiteral(resourceName: "a2")){
            debugPrint($0.title) // code here for click event
        }
        let linkedin = PopoverItem(title: "Linkedin", titleColor: .clear, image: #imageLiteral(resourceName: "a4")){
            debugPrint($0.title) // code here for click event
        }
        return [google, fb, twitter, linkedin]
    }
    
    
    
}

